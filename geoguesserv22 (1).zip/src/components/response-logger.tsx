export function ResponseLogger() {
  return null;
}
