import type React from "react"
export function FarcasterWrapper({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}

export default FarcasterWrapper
