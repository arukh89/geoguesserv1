import GamePage from "@/components/game/GamePage"

export default function Page() {
  return <GamePage />
}
