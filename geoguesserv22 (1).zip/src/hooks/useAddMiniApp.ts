export function useAddMiniApp() {
  return { addMiniApp: async () => void 0 };
}
