"use client"

import MissionNav from "../src/components/game/MissionNav"

export default function SyntheticV0PageForDeployment() {
  return <MissionNav />
}